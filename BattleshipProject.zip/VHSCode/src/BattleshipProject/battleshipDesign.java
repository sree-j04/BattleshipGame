/*
 * sree jessu
 * battleshipDesign
 * 04/25/2021
 * a battleship game that mimics tic tac toe where in a player and the computer take turns battling on the ocean map.
*/
package BattleshipProject;

import java.util.Scanner;

public class battleshipDesign {
    //declaration and initialization of the rows and columns
	public static int totalRows = 10;
    public static int totalColumns = 10;
    
    //declaration of the player and the computer variables
    public static int battleshipPlayer;
    public static int battleshipComputer;
    
    //declaration of player name variable
    public static String name;
    
    //declaration and initialization of the empty grid and the grid with wrong guesses
    public static String[][] map = new String[totalRows][totalColumns];
    public static int[][] wrongGuess = new int[totalRows][totalColumns];

    public static void main(String[] args){
    	//declaration of scanner object named keyboard
    	Scanner keyboard = new Scanner(System.in);
    	
    	//asks player for name
    	System.out.println("This is the Battleship Game.\n Please enter your name below: ");
        name = keyboard.nextLine();
        
        //allows player to enter their name
        System.out.println("Thank you. Now please begin the game.");

        //set up an empty grid where user can see the rows and columns
        emptyGrid();

        //method that allows player's turn to deploy a battleship
        battleshipPlayerDeploy();

        //method that allows computer's turn to deploy a battleship
        battleshipComputerDeploy();

        //the actual battle is shown
        do{
        	BattlefieldGrid();
        }
        while(battleshipDesign.battleshipPlayer != 0 && battleshipDesign.battleshipComputer != 0);

        //Step 5 - Game over
        finishGame();
    }
    
    /*
	 * sree jessu
	 * emptyGrid
	 * 04/25/2021
	 * prints an empty ocean battleship grid with numbered rows and columns
	 * input: n/a
	 * output: empty grid
	 */
    public static void emptyGrid(){
        //space before the numbers are added to the grid
    	System.out.print("   ");
        
        //prints the top columns of the battleship grid
        for(int topCol = 0; topCol < totalColumns; topCol++){
            System.out.print(topCol + "  ");
        }
        //print an empty line
        System.out.println();

        //prints the empty middle section on the grid
        for(int i = 0; i < map.length; i++){
            for (int j = 0; j < map[i].length; j++){
            	map[i][j] = "   ";             
            	//at index i,0 print the number 1, |, and spaces
            	if(j == 0){
                    System.out.print(i + "|" + map[i][j]);
            	//at index i,9 print the number 1, |, and spaces
            	}else if (j == map[i].length - 1){
                    System.out.print(map[i][j] + "|" + i);
                //print empty spaces
            	}else{
                    System.out.print(map[i][j]);
            	}
            }
            //print an empty line
            System.out.println();
        }
  
        System.out.print("  ");
        //prints the bottom columns of the battleship grid
        for(int bottomCol = 0; bottomCol < totalColumns; bottomCol++){
        	System.out.print(bottomCol + "  ");
        }
        //print an empty line
        System.out.println();
    }

    /*
	 * sree jessu
	 * battleshipPlayerDeploy
	 * 04/25/2021
	 * method allows user to enter coordinates of 5 battleships
	 * input: coordinates of the battleships
	 * output: X at the coordinates chosen
	 */
    public static void battleshipPlayerDeploy(){
    	//declaration of scanner object named keyboard
    	Scanner keyboard = new Scanner(System.in);

    	//asks player to deploy a ship
        System.out.println("\nIt is your turn to deploy the battleships");
        //allows player to deploy five ships
        for (int i = 1; i <= 5;){
            //asks player to enter x coordinate for the battleships
        	System.out.print("Please enter the x (row) coordinate for battleship " + i + " below: ");
            //allows player to enter x coordinate for the battleships
        	int x = keyboard.nextInt();
            
            //asks player to enter y coordinate for the battleships
            System.out.print("Please enter the y (column) coordinate for battleship " + i + " below: ");
            //allows player to enter y coordinate for the battleships
            int y = keyboard.nextInt();
            
            //battleship can deployed only if the row and column is within bounds and is empty
            if((x >= 0 && x < totalRows) && (y >= 0 && y < totalColumns) && (map[x][y] == " "))
            {
            	map[x][y] = "X";
                i++;
            }else if((x >= 0 && x < totalRows) && (y >= 0 && y < totalColumns) && map[x][y] == "#"){
                //print message if the location is taken already
            	System.out.println("Sorry! This loaction is taken already.");
            }
            else if((x < 0 || x >= totalRows) || (y < 0 || y >= totalColumns)){
            	//print message if the location is out of bounds
            	System.out.println("Sorry! Battleships cannot be placed outside the grid.");
            }
        }
        //prints the grid map
        GridMap();
    }

    /*
	 * sree jessu
	 * battleshipComputerDeploy
	 * 04/25/2021
	 * method allows computer to enter coordinates of 5 battleships
	 * input: coordinates of the battleships through random number generator
	 * output: # at the coordinates chosen
	 */
    public static void battleshipComputerDeploy(){
        System.out.println("\nComputer is deploying ships");
        //Deploying five ships for computer
        
        for(int j = 1; j <= 5;){
            //system randomly generates an x coordinate
        	int x = (int)(Math.random() * 10);
        	//system randomly generates a y coordinate
            int y = (int)(Math.random() * 10);
            
            // a "#" is placed at the computer chosen coordinate
            if((x >= 0 && x < totalRows) && (y >= 0 && y < totalColumns) && (map[x][y] == " "))
            {
            	map[x][y] = "#";
                //message delivered that the ship has been successfully deployed
            	System.out.println(j + ". ship is deployed by the computer");
                j++;
            }
        }
        //prints the grid map
        GridMap();
    }

    /*
	 * sree jessu
	 * BattlefieldGrid
	 * 04/25/2021
	 * method allows player and computer turns and prints their ships on the grid
	 * input: player and computer method
	 * output: player and computer ships
	 */
    public static void BattlefieldGrid(){
        //the method that allows the player's turn
    	playerDeployment();
    	//the method that allows the computer's turn
    	computerDeployment();
        
        //prints the grid map
        GridMap();

        //print empty line
        System.out.println();
        System.out.println("These are your ships: " + battleshipDesign.battleshipPlayer + " | "
        		+ "There are the Computer ships: " + battleshipDesign.battleshipComputer);
        //print empty line
        System.out.println();
    }

    /*
	 * sree jessu
	 * playerDeployment
	 * 04/25/2021
	 * method allows player to attack the computer battleships
	 * input: coordinate to be attacked
	 * output: symbol according to coordinate picked
	 */
    public static void playerDeployment(){
        //informs player of their turn
    	System.out.println("\nIt is your turn:");
        //declaration and initialization of x and y int to -1
    	int x = -1;
        int y = -1;
        
        do {
        	//declaration of scanner object named keyboard
        	Scanner keyboard = new Scanner(System.in);
            //asks player to enter the x coordinate
        	System.out.print("Please enter your x coordinate: ");
        	//allows player to enter the x coordinate
        	x = keyboard.nextInt();
        	//asks player to enter the y coordinate
            System.out.print("Please enter your y coordinate: ");
            //allows player to enter the y coordinate
            y = keyboard.nextInt();
            
            //if the guess is correct
            if((x >= 0 && x < totalRows) && (y >= 0 && y < totalColumns))
            {
            	//in case there is a computer ship in the coordinate, it is removed
                if(map[x][y] == "#")
                {
                    System.out.println("Congratualations! You sunk the computer's battleship!");
                    //replaces the battleship with a +
                    map[x][y] = "+"; 
                    --battleshipDesign.battleshipComputer;
                }
                //in case there is a player ship, it is attacked
                else if(map[x][y] == "X"){
                    System.out.println("Uh oh you unfortunately attacked your own ship!");
                    //replaces the battleship with an enemy symbol
                    map[x][y] = "#";
                    --battleshipDesign.battleshipPlayer;
                    ++battleshipDesign.battleshipComputer;
                }
                //in case there are no ships at the selected coordinates
                else if(map[x][y] == " "){
                    //gives a message that there are no ships there
                	System.out.println("Sorry, there aren't any ships there!");
                    map[x][y] = "-";
                }
            }
            //if the guess is incorrect (out of bounds)
            else if ((x < 0 || x >= totalRows) || (y < 0 || y >= totalColumns))
                //message that says it's an error
            	System.out.println("Sorry! You cannot attack a ship that is outside the bounds!\nPlease try again!");
        }while((x < 0 || x >= totalRows) || (y < 0 || y >= totalColumns));
    }

    /*
	 * sree jessu
	 * computerDeployment
	 * 04/25/2021
	 * method allows computer to attack the player battleships
	 * input: coordinate to be attacked
	 * output: symbol according to coordinate picked
	 */
    public static void computerDeployment(){
        //message that marks the computer's turn
    	System.out.println("\nIt is now the computer's turn: ");
        //initialization and declaration of variables x and y to -1
        int x = -1;
        int y = -1;
        
        do {
        	//random number generator of x coordinate
            x = (int)(Math.random() * 10);
            //random number generator of y coordinate
            y = (int)(Math.random() * 10);

            //if the guess is within bounds
            if ((x >= 0 && x < totalRows) && (y >= 0 && y < totalColumns))
            {
                //if the player's ship is attacked
            	if (map[x][y] == "X")
                {
                    //message that the player's ships were attacked
            		System.out.println("Uh oh! The computer attacked one of your ships.");
                    //replaces player's ship with #
            		map[x][y] = "#";
                    --battleshipDesign.battleshipPlayer;
                    ++battleshipDesign.battleshipComputer;
                }
                //if computer attacks its own ships
            	else if (map[x][y] == "#"){
                    //message that the computer attacked its own ship
            		System.out.println("Congratulations! The Computer attacked one of its own ships!");
                    //symbol replaced with computer's #
            		map[x][y] = "!";
                }
                //if the computer misses
            	else if (map[x][y] == " "){
                    System.out.println("Oops, the computer selected an empty space");
                    //saves the computer's missed guesses
                    if(wrongGuess[x][y] != 1)
                    	wrongGuess[x][y] = 1;
                }
            }
        // if the attacked coordinate is outside the bounds
        }while((x < 0 || x >= totalRows) || (y < 0 || y >= totalColumns));
    }

    /*
	 * sree jessu
	 * finishGame
	 * 04/25/2021
	 * method shows who won
	 * input: n/a
	 * output: shows who won
	 */
    public static void finishGame(){
        //prints the player's and computer's ships
    	System.out.println("These are your ships: " + battleshipDesign.battleshipPlayer + 
        		" | These are the computer's ships: " + battleshipDesign.battleshipComputer);
    	
    	//if player has more ships left than the computer, they win
        if(battleshipDesign.battleshipPlayer > 0 && battleshipDesign.battleshipComputer <= 0){
            System.out.println("Awesome! You won the battle against the computer!!"); 
        }else{
            //player has less ships than computer and loses
        	System.out.println("So sorry! You lost the battle.");
        //empty line
        System.out.println();
        }
   }

    /*
	 * sree jessu
	 * GridMap
	 * 04/25/2021
	 * method prints the grid map
	 * input: n/a
	 * output: prints the grid map
	 */
    public static void GridMap(){
        //empty line printed
    	System.out.println();
        
        //top section of the ocean grid
        System.out.print("  ");
        for(int i = 0; i < totalColumns; i++){
            System.out.print(i);
        }
        
        //empty line printed
        System.out.println();

        //mid section of the ocean grid
        for(int x = 0; x < map.length; x++){
        	//adds boundaries
        	System.out.print(x + "|");

            for(int y = 0; y < map[x].length; y++){
                System.out.print(map[x][y]);
            }
            
            //adds boundaries
            System.out.println("|" + x);
        }

        //bottom section of the ocean grid
        System.out.print("  ");
        for(int i = 0; i < totalColumns; i++)
            System.out.print(i);
        
        //empty line printed
        System.out.println();
    }
}